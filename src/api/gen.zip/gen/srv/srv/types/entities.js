"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SanitizedEntity = exports.Entity = exports.ConverterService = exports.sap = exports.carbon = void 0;
var carbon;
(function (carbon) {
    let EquivalenciesBucket;
    (function (EquivalenciesBucket) {
        EquivalenciesBucket["XS"] = "XS";
        EquivalenciesBucket["S"] = "S";
        EquivalenciesBucket["M"] = "M";
        EquivalenciesBucket["L"] = "L";
        EquivalenciesBucket["XL"] = "XL";
    })(EquivalenciesBucket = carbon.EquivalenciesBucket || (carbon.EquivalenciesBucket = {}));
    let HabitsCode;
    (function (HabitsCode) {
        HabitsCode["VEGAN"] = "VEGAN";
        HabitsCode["VEGETARIAN"] = "VEGETARIAN";
        HabitsCode["PESCATARIAN"] = "PESCATARIAN";
        HabitsCode["LOW_MEAT_EATER"] = "LOW_MEAT_EATER";
        HabitsCode["DIET_AVERAGE"] = "DIET_AVERAGE";
        HabitsCode["HIGH_MEAT_EATER"] = "HIGH_MEAT_EATER";
        HabitsCode["DIESEL"] = "DIESEL";
        HabitsCode["PETROL"] = "PETROL";
        HabitsCode["FOOD"] = "FOOD";
        HabitsCode["ELECTRICITY"] = "ELECTRICITY";
        HabitsCode["DEFAULT"] = "DEFAULT";
    })(HabitsCode = carbon.HabitsCode || (carbon.HabitsCode = {}));
    let Entity;
    (function (Entity) {
        Entity["Transactions"] = "carbon.Transactions";
        Entity["Challenges"] = "carbon.Challenges";
        Entity["ChallengesUsers"] = "carbon.ChallengesUsers";
        Entity["Equivalencies"] = "carbon.Equivalencies";
        Entity["Accounts"] = "carbon.Accounts";
        Entity["Categories"] = "carbon.Categories";
        Entity["MCC"] = "carbon.MCC";
        Entity["HabitCategories"] = "carbon.HabitCategories";
        Entity["HabitCategoriesMCC"] = "carbon.HabitCategoriesMCC";
        Entity["Habits"] = "carbon.Habits";
        Entity["AccountHabits"] = "carbon.AccountHabits";
    })(Entity = carbon.Entity || (carbon.Entity = {}));
    let SanitizedEntity;
    (function (SanitizedEntity) {
        SanitizedEntity["Transactions"] = "Transactions";
        SanitizedEntity["Challenges"] = "Challenges";
        SanitizedEntity["ChallengesUsers"] = "ChallengesUsers";
        SanitizedEntity["Equivalencies"] = "Equivalencies";
        SanitizedEntity["Accounts"] = "Accounts";
        SanitizedEntity["Categories"] = "Categories";
        SanitizedEntity["MCC"] = "MCC";
        SanitizedEntity["HabitCategories"] = "HabitCategories";
        SanitizedEntity["HabitCategoriesMCC"] = "HabitCategoriesMCC";
        SanitizedEntity["Habits"] = "Habits";
        SanitizedEntity["AccountHabits"] = "AccountHabits";
    })(SanitizedEntity = carbon.SanitizedEntity || (carbon.SanitizedEntity = {}));
})(carbon = exports.carbon || (exports.carbon = {}));
var sap;
(function (sap) {
    var common;
    (function (common) {
        let Entity;
        (function (Entity) {
            Entity["Languages"] = "sap.common.Languages";
            Entity["Countries"] = "sap.common.Countries";
            Entity["Currencies"] = "sap.common.Currencies";
            Entity["Texts"] = "sap.common.Currencies.texts";
        })(Entity = common.Entity || (common.Entity = {}));
        let SanitizedEntity;
        (function (SanitizedEntity) {
            SanitizedEntity["Languages"] = "Languages";
            SanitizedEntity["Countries"] = "Countries";
            SanitizedEntity["Currencies"] = "Currencies";
            SanitizedEntity["Texts"] = "Texts";
        })(SanitizedEntity = common.SanitizedEntity || (common.SanitizedEntity = {}));
    })(common = sap.common || (sap.common = {}));
})(sap = exports.sap || (exports.sap = {}));
var ConverterService;
(function (ConverterService) {
    let HabitsCode;
    (function (HabitsCode) {
        HabitsCode["VEGAN"] = "VEGAN";
        HabitsCode["VEGETARIAN"] = "VEGETARIAN";
        HabitsCode["PESCATARIAN"] = "PESCATARIAN";
        HabitsCode["LOW_MEAT_EATER"] = "LOW_MEAT_EATER";
        HabitsCode["DIET_AVERAGE"] = "DIET_AVERAGE";
        HabitsCode["HIGH_MEAT_EATER"] = "HIGH_MEAT_EATER";
        HabitsCode["DIESEL"] = "DIESEL";
        HabitsCode["PETROL"] = "PETROL";
        HabitsCode["FOOD"] = "FOOD";
        HabitsCode["ELECTRICITY"] = "ELECTRICITY";
        HabitsCode["DEFAULT"] = "DEFAULT";
    })(HabitsCode = ConverterService.HabitsCode || (ConverterService.HabitsCode = {}));
    let EquivalenciesBucket;
    (function (EquivalenciesBucket) {
        EquivalenciesBucket["XS"] = "XS";
        EquivalenciesBucket["S"] = "S";
        EquivalenciesBucket["M"] = "M";
        EquivalenciesBucket["L"] = "L";
        EquivalenciesBucket["XL"] = "XL";
    })(EquivalenciesBucket = ConverterService.EquivalenciesBucket || (ConverterService.EquivalenciesBucket = {}));
    let FuncGetEquivalencies;
    (function (FuncGetEquivalencies) {
        FuncGetEquivalencies["name"] = "getEquivalencies";
        FuncGetEquivalencies["paramCo2"] = "co2";
        FuncGetEquivalencies["paramAccount"] = "account";
    })(FuncGetEquivalencies = ConverterService.FuncGetEquivalencies || (ConverterService.FuncGetEquivalencies = {}));
    let FuncGetAccountData;
    (function (FuncGetAccountData) {
        FuncGetAccountData["name"] = "getAccountData";
        FuncGetAccountData["paramAccount"] = "account";
    })(FuncGetAccountData = ConverterService.FuncGetAccountData || (ConverterService.FuncGetAccountData = {}));
    let ActionAiProxy;
    (function (ActionAiProxy) {
        ActionAiProxy["name"] = "aiProxy";
        ActionAiProxy["paramPrompt"] = "prompt";
    })(ActionAiProxy = ConverterService.ActionAiProxy || (ConverterService.ActionAiProxy = {}));
    let ActionGenerateSuggestions;
    (function (ActionGenerateSuggestions) {
        ActionGenerateSuggestions["name"] = "generateSuggestions";
        ActionGenerateSuggestions["paramCategory"] = "category";
        ActionGenerateSuggestions["paramSpendings"] = "spendings";
        ActionGenerateSuggestions["paramCO2Score"] = "CO2Score";
        ActionGenerateSuggestions["paramAmountOfTransactions"] = "amountOfTransactions";
    })(ActionGenerateSuggestions = ConverterService.ActionGenerateSuggestions || (ConverterService.ActionGenerateSuggestions = {}));
    let ActionGenerateCategorizedSummary;
    (function (ActionGenerateCategorizedSummary) {
        ActionGenerateCategorizedSummary["name"] = "generateCategorizedSummary";
        ActionGenerateCategorizedSummary["paramCategorizedSummary"] = "categorizedSummary";
    })(ActionGenerateCategorizedSummary = ConverterService.ActionGenerateCategorizedSummary || (ConverterService.ActionGenerateCategorizedSummary = {}));
    let ActionGenerateHistoricalSummary;
    (function (ActionGenerateHistoricalSummary) {
        ActionGenerateHistoricalSummary["name"] = "generateHistoricalSummary";
        ActionGenerateHistoricalSummary["paramHistoricalSummary"] = "historicalSummary";
    })(ActionGenerateHistoricalSummary = ConverterService.ActionGenerateHistoricalSummary || (ConverterService.ActionGenerateHistoricalSummary = {}));
    let ActionAskForComposition;
    (function (ActionAskForComposition) {
        ActionAskForComposition["name"] = "askForComposition";
        ActionAskForComposition["paramName"] = "name";
        ActionAskForComposition["paramContract"] = "contract";
        ActionAskForComposition["paramAddress"] = "address";
        ActionAskForComposition["paramProvider"] = "provider";
    })(ActionAskForComposition = ConverterService.ActionAskForComposition || (ConverterService.ActionAskForComposition = {}));
    let ActionAskForGreenContract;
    (function (ActionAskForGreenContract) {
        ActionAskForGreenContract["name"] = "askForGreenContract";
        ActionAskForGreenContract["paramName"] = "name";
        ActionAskForGreenContract["paramContract"] = "contract";
        ActionAskForGreenContract["paramAddress"] = "address";
        ActionAskForGreenContract["paramProvider"] = "provider";
    })(ActionAskForGreenContract = ConverterService.ActionAskForGreenContract || (ConverterService.ActionAskForGreenContract = {}));
    let ActionAskForChallengeBenefits;
    (function (ActionAskForChallengeBenefits) {
        ActionAskForChallengeBenefits["name"] = "askForChallengeBenefits";
        ActionAskForChallengeBenefits["paramTitle"] = "title";
        ActionAskForChallengeBenefits["paramDescription"] = "description";
        ActionAskForChallengeBenefits["paramAvoidableEmissionsPerDay"] = "avoidableEmissionsPerDay";
    })(ActionAskForChallengeBenefits = ConverterService.ActionAskForChallengeBenefits || (ConverterService.ActionAskForChallengeBenefits = {}));
    let ActionAskForHabitRecommendation;
    (function (ActionAskForHabitRecommendation) {
        ActionAskForHabitRecommendation["name"] = "askForHabitRecommendation";
        ActionAskForHabitRecommendation["paramQuestion"] = "question";
        ActionAskForHabitRecommendation["paramCurrentHabit"] = "currentHabit";
        ActionAskForHabitRecommendation["paramHabitSummaries"] = "habitSummaries";
    })(ActionAskForHabitRecommendation = ConverterService.ActionAskForHabitRecommendation || (ConverterService.ActionAskForHabitRecommendation = {}));
    let ActionStartChallenge;
    (function (ActionStartChallenge) {
        ActionStartChallenge["name"] = "startChallenge";
        ActionStartChallenge["paramAccount"] = "account";
        ActionStartChallenge["paramChallengeId"] = "challengeId";
    })(ActionStartChallenge = ConverterService.ActionStartChallenge || (ConverterService.ActionStartChallenge = {}));
    let ActionCancelChallenge;
    (function (ActionCancelChallenge) {
        ActionCancelChallenge["name"] = "cancelChallenge";
        ActionCancelChallenge["paramId"] = "id";
    })(ActionCancelChallenge = ConverterService.ActionCancelChallenge || (ConverterService.ActionCancelChallenge = {}));
    let ActionCompleteChallenge;
    (function (ActionCompleteChallenge) {
        ActionCompleteChallenge["name"] = "completeChallenge";
        ActionCompleteChallenge["paramId"] = "id";
    })(ActionCompleteChallenge = ConverterService.ActionCompleteChallenge || (ConverterService.ActionCompleteChallenge = {}));
    let ActionSetHabit;
    (function (ActionSetHabit) {
        ActionSetHabit["name"] = "setHabit";
        ActionSetHabit["paramAccount"] = "account";
        ActionSetHabit["paramHabitCategory"] = "habitCategory";
        ActionSetHabit["paramHabit"] = "habit";
        ActionSetHabit["paramTransaction"] = "transaction";
    })(ActionSetHabit = ConverterService.ActionSetHabit || (ConverterService.ActionSetHabit = {}));
    let Entity;
    (function (Entity) {
        Entity["Transactions"] = "ConverterService.Transactions";
        Entity["AccountHabits"] = "ConverterService.AccountHabits";
        Entity["Accounts"] = "ConverterService.Accounts";
        Entity["Habits"] = "ConverterService.Habits";
        Entity["Challenges"] = "ConverterService.Challenges";
        Entity["ChallengesUsers"] = "ConverterService.ChallengesUsers";
        Entity["Categories"] = "ConverterService.Categories";
        Entity["MCC"] = "ConverterService.MCC";
        Entity["HabitCategories"] = "ConverterService.HabitCategories";
        Entity["Equivalencies"] = "ConverterService.Equivalencies";
        Entity["ISuggestion"] = "ConverterService.ISuggestion";
        Entity["IMonthlyCO2"] = "ConverterService.IMonthlyCO2";
        Entity["ICategorizedCO2"] = "ConverterService.ICategorizedCO2";
        Entity["IHabitSummary"] = "ConverterService.IHabitSummary";
        Entity["GPTAnswer"] = "ConverterService.GPTAnswer";
        Entity["HabitCategoriesMCC"] = "ConverterService.HabitCategoriesMCC";
    })(Entity = ConverterService.Entity || (ConverterService.Entity = {}));
    let SanitizedEntity;
    (function (SanitizedEntity) {
        SanitizedEntity["Transactions"] = "Transactions";
        SanitizedEntity["AccountHabits"] = "AccountHabits";
        SanitizedEntity["Accounts"] = "Accounts";
        SanitizedEntity["Habits"] = "Habits";
        SanitizedEntity["Challenges"] = "Challenges";
        SanitizedEntity["ChallengesUsers"] = "ChallengesUsers";
        SanitizedEntity["Categories"] = "Categories";
        SanitizedEntity["MCC"] = "MCC";
        SanitizedEntity["HabitCategories"] = "HabitCategories";
        SanitizedEntity["Equivalencies"] = "Equivalencies";
        SanitizedEntity["ISuggestion"] = "ISuggestion";
        SanitizedEntity["IMonthlyCO2"] = "IMonthlyCO2";
        SanitizedEntity["ICategorizedCO2"] = "ICategorizedCO2";
        SanitizedEntity["IHabitSummary"] = "IHabitSummary";
        SanitizedEntity["GPTAnswer"] = "GPTAnswer";
        SanitizedEntity["HabitCategoriesMCC"] = "HabitCategoriesMCC";
    })(SanitizedEntity = ConverterService.SanitizedEntity || (ConverterService.SanitizedEntity = {}));
})(ConverterService = exports.ConverterService || (exports.ConverterService = {}));
var Entity;
(function (Entity) {
})(Entity = exports.Entity || (exports.Entity = {}));
var SanitizedEntity;
(function (SanitizedEntity) {
})(SanitizedEntity = exports.SanitizedEntity || (exports.SanitizedEntity = {}));
