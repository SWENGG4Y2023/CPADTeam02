"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cds_1 = __importDefault(require("@sap/cds"));
const cors_1 = __importDefault(require("cors"));
cds_1.default.on("bootstrap", (app) => {
    const envs = process.env;
    const API_KEY_CAP = envs["API_KEY"];
    app.use((0, cors_1.default)());
    app.get("/*", (req, res, next) => {
        const API_KEY_HEADER = req.headers["api-key"];
        if (!API_KEY_CAP) {
            return res.status(500).send("CAP is not properly configured. Please add API_KEY to environment variables.");
        }
        if (!API_KEY_HEADER) {
            return res.status(400).send("api-key header is missing.");
        }
        if (API_KEY_CAP === API_KEY_HEADER) {
            return next();
        }
        else {
            return res.status(400).send("Wrong api-key.");
        }
    });
});
