"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConverterService = void 0;
const cds_1 = __importStar(require("@sap/cds"));
const moment_1 = __importDefault(require("moment"));
const uuid_1 = require("uuid");
const entities_1 = require("./types/entities");
// PARAMETERS FOR accessing foundation model
const MAX_TOKENS = 500;
const TEMPERATURE = 0.8;
const FREQUENCY_PENALTY = 0;
const PRESENCE_PENALTY = 0;
const STOP_SEQUENCE = null;
const Gen_AI_Model_PARAMS = {
    temperature: TEMPERATURE,
};
class ConverterService extends cds_1.ApplicationService {
    constructor() {
        super(...arguments);
        /**
         * Action forwarding prompt to Azure OpenAI services through SAP AI Core provided proxy
         *
         * @param {Request} req
         * @returns GPTTextResponse { text : string }
         */
        this.aiProxy = async (req) => {
            const { prompt } = req.data;
            const response = await this.callAIProxy(prompt);
            return { text: response["choices"][0].message.content };
        };
        /**
         * Forwards prompt of the payload via a destination (mapped as SAPGENERATIVEAIHUB) through an SAP AI Core deployed service to foundation models
         *
         * @param {string} prompt
         * @returns raw response from SAP Gen AI Hub Foundation models of Azure OpenAI
         */
        this.callAIProxy = async (prompt) => {
            const generativeAIHub = await cds_1.default.connect.to("SAPGENERATIVEAIHUB");
            const payload = Object.assign(Object.assign({}, Gen_AI_Model_PARAMS), { messages: [
                    { role: "system", content: "Assistant is a large language model trained by OpenAI" },
                    { role: "user", content: prompt }
                ] });
            // @ts-ignore
            const response = await generativeAIHub.send({
                // @ts-ignore
                // method: "POST",
                query: "POST /chat/completions?api-version=2023-05-15",
                data: payload
            });
            return response;
        };
        this.callSAPGENERATIVEAIHUB = async (prompt) => {
            try {
                const generativeAIHub = await cds_1.default.connect.to("SAPGENERATIVEAIHUB");
                const payload = Object.assign(Object.assign({}, Gen_AI_Model_PARAMS), { messages: [
                        { role: "system", content: "Assistant is a large language model trained by OpenAI" },
                        { role: "user", content: prompt }
                    ] });
                // @ts-ignore
                const response = await generativeAIHub.send({
                    // @ts-ignore
                    // method: "POST",
                    query: "POST /chat/completions?api-version=2023-05-15",
                    data: payload
                });
                console.log("gpt response is : " + response);
                return (response["choices"][0].message.content || "").trim(); //replace leading or trailing new lines and whitespaces
            }
            catch (e) {
                console.error("error is : " + e);
                return "Error: Something went wrong";
            }
        };
        this.generateCategorizedSummary = async (req) => {
            const { categorizedSummary } = req.data;
            let prompt = `The following is a table of my CO2 consumption of the current month for different categories of spendings: 
Category | CO2 consumption in kg 
---+--- 
        `;
            // filter out zeros
            const relevantCategories = categorizedSummary.filter(({ category: _, co2 }) => co2 > 0);
            // generate table content inside prompt
            relevantCategories.forEach(({ category, co2 }) => {
                prompt += `${category} | ${co2}\n`;
            });
            prompt += `
            Tell me which category has the highest consumption.
            Also propose three measures how I could decrease the CO2 consumption fo this category.
            No table please, just a plain text which I can listen to in spoken speech and numbers rounded.`;
            const response = await this.callSAPGENERATIVEAIHUB(prompt);
            return { text: response };
        };
        this.generateHistoricalSummary = async (req) => {
            let { historicalSummary } = req.data;
            let prompt = `The following is a table with my CO2 consumption in the previous months, last one is the current month:
Year | Month | CO2 consumption in kg
-----+-------+---\n`;
            historicalSummary.forEach(({ year, month, co2 }) => {
                prompt += `${year} | ${month} | ${co2} |\n`;
            });
            prompt += `
Give me a summary on how my consumption has evolved over the past months.
Then give me a trend over the last three months only.
Finally, rate my progress whether it is improving or worsening.
No table please, just a plain text which I can listen to in spoken speech and numbers rounded.

Your CO2 consumption...

The trend over the last three months...

Your progress...`;
            const response = await this.callSAPGENERATIVEAIHUB(prompt);
            return { text: response };
        };
        this.askForComposition = async (req) => {
            const { name, contract, address, provider } = req.data;
            const prompt = `Write an email with the following purpose: ask my energy provider ${provider} about my current contract, how much of the electricity is renewable. Keep it short but polite. Address the provider in a neutral form, not by name.
        In the email, use the following placeholders: ${name} for my name, ${contract} for my contract number, ${address} for my address, no more.`;
            const response = await this.callSAPGENERATIVEAIHUB(prompt);
            return { text: response };
        };
        this.askForGreenContract = async (req) => {
            const { name, contract, address, provider } = req.data;
            const prompt = `Write an email with the following purpose: ask my energy provider ${provider} about my current contract for an alternate more environmental friendly contract for electricity. Keep it short but polite. Address the provider in a neutral form, not by name.
        In the email, use the following placeholders: ${name} for my name, ${contract} for my contract number, ${address} for my address, no more.`;
            const response = await this.callSAPGENERATIVEAIHUB(prompt);
            return { text: response };
        };
        this.askForChallengeBenefits = async (req) => {
            const { title, description, avoidableEmissionsPerDay } = req.data;
            const prompt = `Generate a motivation for a ${title} to reduce co2 emissions. The challenge covers the following by avoiding ${avoidableEmissionsPerDay} kg co2 per fullfilled day: ${description}. Why should I do this challenge?`;
            const response = await this.callSAPGENERATIVEAIHUB(prompt);
            return { text: response };
        };
        this.askForHabitRecommendation = async (req) => {
            const { question, currentHabit, habitSummaries } = req.data;
            let prompt = `Imagine a user gets asked the following question: ${question}
The following options are avaialble:
Option | Habit | Percentage of CO2 consumption compared to default habit
-----+-------+---\n`;
            habitSummaries.forEach(({ option, context, factor }) => {
                prompt += `${option} | ${context} | ${Math.round(factor * 100)}% |\n`;
            });
            prompt += `
Give the user a summary of the options, recommendation and step by step guide in one flowing text on how its co2 emissions could be reduced, if its current habit is ${currentHabit}`;
            const response = await this.callSAPGENERATIVEAIHUB(prompt);
            return { text: response };
        };
        this.generateSuggestions = async (req) => {
            try {
                const { category, spendings, CO2Score, amountOfTransactions } = req.data;
                const prompt = `Provide 5 suggestions with a title and description (2-3 sentences) as a JSON array in the format [{"title": "", "description": "" }] without any additional text to help me reduce my CO2 footprint of ${CO2Score.toFixed(0)} kg related to ${category} (MCC parent category). My monthly spending is over ${spendings.toFixed(0)} INR with ${amountOfTransactions} transactions. Act as a REST API with Content-Type application/json,keep only json array in response`;
                const response = await this.callSAPGENERATIVEAIHUB(prompt);
                return JSON.parse(response);
            }
            catch (e) {
                console.error(e);
                return [];
            }
        };
        /*
            Equivalencies / Similarities could be taken from
            Connect Earth - Connect Insights API (Transaction Emissions).
            For more information follow the link to
            https://docs.connect.earth/?id=-nbsp-connect-insights-transaction-emissions
        */
        this.getEquivalencies = async (req) => {
            try {
                const { co2, account } = req.data;
                const { AccountHabits, Equivalencies } = this.entities;
                const accountHabits = await SELECT.from(AccountHabits)
                    .where({ account_ID: account, transaction: null })
                    .columns((ah) => {
                    ah("*");
                    ah.habit((h) => h("*"));
                });
                const habits = accountHabits.map((ah) => ah.habit.code);
                const isVegan = habits.some((habit) => habit === entities_1.ConverterService.HabitsCode.VEGAN);
                const bucket = this.excludeBucket(co2);
                const filter = Object.assign({ bucket: { "!=": bucket } }, (isVegan && { vegan: true }));
                const rawEquivalencies = await SELECT.from(Equivalencies).where(filter).limit(5).orderBy("RAND()");
                const equivalencies = rawEquivalencies.map((e) => ({
                    ID: e.ID,
                    amount: Math.round(co2 / e.co2PerKg) > 10
                        ? Math.round(co2 / e.co2PerKg)
                        : Math.round((co2 / e.co2PerKg) * 100) / 100,
                    description: e.description,
                    image: e.image
                }));
                return equivalencies;
            }
            catch (e) {
                console.error(e);
                return [];
            }
        };
        /*
            CO2 Footprint inclusive user habits could be calculated using
            Connect Earth - Connect Insights API (Transaction Emissions).
            For more information follow the link to
            https://docs.connect.earth/?id=-nbsp-connect-insights-transaction-emissions
        */
        this.getAccountData = async (req) => {
            const { account: accountId } = req.data;
            const { Accounts, HabitCategoriesMCC } = this.entities;
            const account = await SELECT.one
                .from(Accounts)
                .where({ ID: accountId })
                .columns((account) => {
                account("*");
                // expand AccountHabits
                account.habits((ah) => {
                    ah("*");
                    // expand Habits inside AccountHabits
                    ah.habit((h) => h("*"));
                });
                account.challenges((c) => {
                    c("*");
                    c.challenge((c) => c("*"));
                });
                account.transactions((t) => {
                    t("*");
                    t.mcc((mcc) => {
                        mcc("*");
                        mcc.category((category) => category("*"));
                    });
                });
            });
            const transactions = account.transactions;
            const offset = this.getOffsetToAddInDays();
            const accountHabits = account.habits;
            const habitCategoriesMCC = await SELECT.from(HabitCategoriesMCC);
            // create mapping for MCC => HabitCategory for further O(1) access
            const mccHabitMapping = habitCategoriesMCC.reduce((mapping, v) => v.mcc_ID
                ? Object.assign(Object.assign({}, mapping), { [v.mcc_ID]: v.habitCategory_ID }) : mapping, {});
            for (const transaction of transactions) {
                transaction.date = (0, moment_1.default)(transaction.date).add(offset, "d").toDate();
                let habitFactor = 1.0; // default if no habit is set
                // check if MCC is part of any habit category
                try {
                    if (transaction.mcc_ID in mccHabitMapping) {
                        // filter account based habits for relevant habit categories based on MCC
                        const relevantAccountHabits = accountHabits.filter((habit) => { var _a; return ((_a = habit.habit) === null || _a === void 0 ? void 0 : _a.habitCategory_ID) === mccHabitMapping[transaction.mcc_ID]; });
                        // check the relevant personal habits, set the factor but break if any personal habit was overriden wrt a transaction
                        for (const habit of relevantAccountHabits) {
                            habitFactor = habit.habit.factor;
                            if (habit.transaction_ID === transaction.ID) {
                                console.log("transaction based habit found");
                                break;
                            }
                            else {
                                console.log("mcc based habit found");
                            }
                        }
                    }
                }
                catch (e) {
                    console.log("Something went wrong calculating the individual habit factor", e);
                }
                transaction.CO2Score *= habitFactor;
                transaction.CO2Score = Math.round(transaction.CO2Score * 100) / 100;
            }
            return account;
        };
        this.getOffsetToAddInDays = () => {
            const lastTxMonth = (0, moment_1.default)("04-01-2023", "MM-DD-YYYY");
            const currentMonth = (0, moment_1.default)();
            return Math.round(currentMonth.diff(lastTxMonth, "days", true));
        };
        this.startChallenge = async (req) => {
            const CHALLENGE_DURATION = 1000 * 3600 * 24 * 30; // 30 days
            const { account, challengeId } = req.data;
            const uuid = (0, uuid_1.v4)();
            await INSERT.into(entities_1.ConverterService.Entity.ChallengesUsers).entries({
                ID: uuid,
                account_ID: account,
                challenge_ID: challengeId,
                markedDates: "[]",
                startDate: new Date().toISOString().split("T")[0],
                // challenge due date is 30 days from today
                dueDate: new Date(Date.now() + CHALLENGE_DURATION).toISOString().split("T")[0],
                isCompleted: false
            });
            return { challengeId: uuid };
        };
        this.cancelChallenge = async (req) => {
            const { id } = req.data;
            await DELETE.from(entities_1.ConverterService.Entity.ChallengesUsers, { ID: id });
        };
        this.completeChallenge = async (req) => {
            const { id } = req.data;
            await UPDATE(entities_1.ConverterService.Entity.ChallengesUsers).where({ ID: id }).with({ isCompleted: true });
        };
        this.setHabit = async (req) => {
            const { account, habitCategory, habit, transaction } = req.data;
            // defaults for diet and fuel habit
            const DEFAULT_HABITS = ["740fcc4f-518d-4bb0-9b69-697a38361926", "59ee24e3-3f1e-48a3-99f3-144d0dc48258"];
            const isDefault = DEFAULT_HABITS.includes(habit);
            const accountHabits = await SELECT `from carbon.AccountHabits {*, habit.habitCategory_ID}`;
            const relevantAccountHabit = accountHabits.find((ah) => ah.habitCategory_ID == habitCategory && ah.transaction_ID == transaction && ah.account_ID == account);
            if (!isDefault) {
                if (relevantAccountHabit) {
                    await cds_1.default
                        .update(entities_1.ConverterService.Entity.AccountHabits)
                        .where({ ID: relevantAccountHabit.ID })
                        .with({ habit_ID: habit });
                }
                else {
                    await cds_1.default.create(entities_1.ConverterService.Entity.AccountHabits, {
                        account_ID: account,
                        transaction_ID: transaction,
                        habit_ID: habit
                    });
                }
            }
            else if (isDefault && relevantAccountHabit) {
                // delete account habit to indicate that default habit should be used in co2 calculation
                await cds_1.default.delete(entities_1.ConverterService.Entity.AccountHabits, relevantAccountHabit.ID);
            }
        };
    }
    async init() {
        await super.init();
        this.on(entities_1.ConverterService.FuncGetEquivalencies.name, this.getEquivalencies);
        this.on(entities_1.ConverterService.ActionAiProxy.name, this.aiProxy);
        this.on(entities_1.ConverterService.ActionGenerateSuggestions.name, this.generateSuggestions);
        this.on(entities_1.ConverterService.ActionGenerateCategorizedSummary.name, this.generateCategorizedSummary);
        this.on(entities_1.ConverterService.ActionGenerateHistoricalSummary.name, this.generateHistoricalSummary);
        this.on(entities_1.ConverterService.ActionStartChallenge.name, this.startChallenge);
        this.on(entities_1.ConverterService.ActionCancelChallenge.name, this.cancelChallenge);
        this.on(entities_1.ConverterService.ActionCompleteChallenge.name, this.completeChallenge);
        this.on(entities_1.ConverterService.ActionSetHabit.name, this.setHabit);
        this.on(entities_1.ConverterService.ActionAskForComposition.name, this.askForComposition);
        this.on(entities_1.ConverterService.ActionAskForGreenContract.name, this.askForGreenContract);
        this.on(entities_1.ConverterService.ActionAskForChallengeBenefits.name, this.askForChallengeBenefits);
        this.on(entities_1.ConverterService.ActionAskForHabitRecommendation.name, this.askForHabitRecommendation);
        this.on(entities_1.ConverterService.FuncGetAccountData.name, this.getAccountData);
    }
    excludeBucket(value) {
        if (value < 500)
            return entities_1.ConverterService.EquivalenciesBucket.XL;
        if (value > 10)
            return entities_1.ConverterService.EquivalenciesBucket.XS;
        return null;
    }
}
exports.ConverterService = ConverterService;
